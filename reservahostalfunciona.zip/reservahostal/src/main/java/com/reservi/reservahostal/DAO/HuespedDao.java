package com.reservi.reservahostal.DAO;
import com.reservi.reservahostal.Models.Huesped;
import org.springframework.data.repository.CrudRepository;

public interface HuespedDao extends CrudRepository<Huesped,Integer>{
    
}
