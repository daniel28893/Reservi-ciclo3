package com.reservi.reservahostal.Service;
import com.reservi.reservahostal.Models.habitacion;
import java.util.List;
public interface habitacionService {
    public habitacion save(habitacion habitacion);
    public void delete(Integer id);
    public habitacion findById(Integer id);
    public List<habitacion> findByAll();
}
