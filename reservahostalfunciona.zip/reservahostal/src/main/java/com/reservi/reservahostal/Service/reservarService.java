package com.reservi.reservahostal.Service;

import com.reservi.reservahostal.Models.reservar;
import java.util.List;

public interface reservarService {
    public reservar save (reservar reservar);
    public void delete(Integer id);
    public reservar findById(Integer id);
    public List<reservar> findByAll();
}
