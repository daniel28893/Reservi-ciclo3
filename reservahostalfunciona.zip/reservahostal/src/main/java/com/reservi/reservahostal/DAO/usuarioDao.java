package com.reservi.reservahostal.DAO;
import com.reservi.reservahostal.Models.usuario;
import org.springframework.data.repository.CrudRepository;

public interface usuarioDao extends CrudRepository<usuario,Integer>{
    
}