const url = "http://localhost:8080/reservar/"
const url1 = "http://localhost:8080/reservar/list/"
const contenedor = document.querySelector('tbody')
let resultados = ''

const modalReserva = new bootstrap.Modal(document.getElementById('modalReservas'))
const formReserva = document.querySelector('form')
const codigoReserva = document.getElementById('codigo_re')
const fechaReserva = document.getElementById('fecha_reserva')
const numeroHabitacion = document.getElementById('numero_habi')
const idHuesped = document.getElementById('id_hue')
const codigoEstadoReserva = document.getElementById('codigo_estReser')
const nombreEstadoReserva = document.getElementById('nombre_estReser')
const usuario = document.getElementById('id_usuario')
let opcion = ''

btnCrear.addEventListener('click', () => {
    codigoReserva.value = ''
    fechaReserva.value = ''
    numeroHabitacion.value = ''
    idHuesped.value = ''
    codigoEstadoReserva.value = ''
    nombreEstadoReserva.value = ''
    usuario.value = ''
    codigoReserva.disabled = false
    modalReservas.show()
    opcion = 'crear'
})

btnCerrar.addEventListener('click', () => {
    
    modalReservas.hide()
   
})

btnclose.addEventListener('click', () => {
    
    modalReservas.hide()
   
})
//funcion para mostrar resultados

const mostrar = (Reserva) => {
    Reserva.forEach(Reserva => {
        resultados += `<tr>
                        <td>${Reserva.codigo_rese}</td>
                        <td>${Reserva.fecha_reserva}</td>
                        <td>${Reserva.habitacion.numero_habi}</td>
                        <td>${Reserva.huesped.id_hue}</td>
                        <td>${Reserva.codigo_estReser}</td>
                        <td>${Reserva.nombre_estReser}</td>
                        <td>${Reserva.usuario.id_usuario}</td>
                        <td class="text-center" width="20%"><a class="btnEditar btn btn-primary">Editar</a><a class="btnBorrar btn btn-danger">Borrar</a></td>
                    </tr>`
    })

    contenedor.innerHTML = resultados
}

//procedimiento mostrar registros
fetch(url1)
    .then(response => response.json())
    .then(data => mostrar(data))
    .catch(error => console.log(error))

const on = (element, event, selector, handler) => {
    element.addEventListener(event, e => {
        if (e.target.closest(selector))
            handler(e)
    })
}

on(document, 'click', '.btnBorrar', e => {
    const fila = e.target.parentNode.parentNode
    const codigoReserva = fila.firstElementChild.innerHTML
    console.log(codigoReserva)

    alertify.confirm("Desea eliminar el numero de Reserva "+codigoReserva,
        function () {
            fetch(url + codigoReserva, {
                method: 'DELETE'
            })
                .then(() => location.reload())
        },
        function () {
            alertify.error('Cancelado')
        });
})

let idForm = 0
on(document, 'click', '.btnEditar', e => {
    const fila = e.target.parentNode.parentNode
    idForm = fila.children[0].innerHTML
    const nombre = fila.children[1].innerHTML
    const email = fila.children[2].innerHTML
    idReserva.value = idForm
    nombreReserva.value = nombre
    emailReserva.value = email
    idReserva.disabled = true
    opcion = 'editar'
    modalReservas.show()
})

formReserva.addEventListener('submit', (e) => {
    e.preventDefault()

        if (opcion == 'crear') {
            fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    id_reserva: idReserva.value,
                    nombre_reserva: nombreReserva.value,
                    email_reserva: emailReserva.value
                })
            })
                .then(response => response.json())
                .then(data => {
                    const nuevoReserva = []
                    nuevoReserva.push(data)
                    mostrar(nuevoReserva)
                })
        }
        if (opcion == 'editar') {

            fetch(url, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    id_reserva: idForm,
                    nombre_reserva: nombreReserva.value,
                    email_reserva: emailReserva.value
                })
            })
                .then(response => location.reload())

        }
        modalReservas.hide()
})