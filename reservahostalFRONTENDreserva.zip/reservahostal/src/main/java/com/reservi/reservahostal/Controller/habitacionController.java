package com.reservi.reservahostal.Controller;
import com.reservi.reservahostal.Models.habitacion;
import com.reservi.reservahostal.Service.habitacionService;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin("*")
@RequestMapping("/habitacion")
public class habitacionController {
    @Autowired
    private habitacionService habitacionService;
    
    @PostMapping(value="/")
    public ResponseEntity<habitacion> agregar(@RequestBody habitacion habitacion){
        habitacion obj = habitacionService.save(habitacion);
        return new ResponseEntity<>(obj, HttpStatus.OK);
    }
    
    @DeleteMapping(value="/{id}")
    public ResponseEntity<habitacion> eliminar(@PathVariable Integer id){
        habitacion obj = habitacionService.findById(id);
        if(obj!=null){
            habitacionService.delete(id);
        } else {
            return new ResponseEntity<>(obj, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(obj, HttpStatus.OK);
    }
    
    @PutMapping(value="/")
    public ResponseEntity<habitacion> editar(@RequestBody habitacion habitacion){
        habitacion obj = habitacionService.findById(habitacion.getNumero_habi());
        if(obj!=null){
            obj.setNumero_habi(habitacion.getNumero_habi());
            obj.setTipo_habi(habitacion.getTipo_habi());
            obj.setUbicacion(habitacion.getUbicacion());
            obj.setCodigo_esthab(habitacion.getCodigo_esthab());
            obj.setNombre_esthab(habitacion.getNombre_esthab());
            habitacionService.save(obj);
        } else {
            return new ResponseEntity<>(obj, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(obj, HttpStatus.OK);
    }
    
    @GetMapping("/list")
    public List<habitacion> consultarTodo(){
        return habitacionService.findByAll();
    }
    
    @GetMapping("/list/{id}")
    public habitacion consultarPorId(@PathVariable Integer id){
        return habitacionService.findById(id);
    }

}


    

