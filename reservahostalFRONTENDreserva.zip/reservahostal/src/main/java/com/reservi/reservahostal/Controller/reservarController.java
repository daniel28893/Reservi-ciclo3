package com.reservi.reservahostal.Controller;
import com.reservi.reservahostal.Models.reservar;
import com.reservi.reservahostal.Service.reservarService;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
@CrossOrigin("*")
@RequestMapping("/reservar")
public class reservarController {
  @Autowired
    private reservarService reservarService;
    
    @PostMapping(value="/")
    public ResponseEntity<reservar> agregar(@RequestBody reservar reservar){
        reservar obj = reservarService.save(reservar);
        return new ResponseEntity<>(obj, HttpStatus.OK);
    }
    
    @DeleteMapping(value="/{id}")
    public ResponseEntity<reservar> eliminar(@PathVariable Integer id){
        reservar obj = reservarService.findById(id);
        if(obj!=null){
            reservarService.delete(id);
        } else {
            return new ResponseEntity<>(obj, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(obj, HttpStatus.OK);
    }
    
    @PutMapping(value="/")
    public ResponseEntity<reservar> editar(@RequestBody reservar reservar){
        reservar obj = reservarService.findById(reservar.getCodigo_rese());
        if(obj!=null){
            obj.setCodigo_rese(reservar.getCodigo_rese());
            obj.setHabitacion(reservar.getHabitacion());
            obj.setHuesped(reservar.getHuesped());
            obj.setUsuario(reservar.getUsuario());
            reservarService.save(obj);
        } else {
            return new ResponseEntity<>(obj, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return new ResponseEntity<>(obj, HttpStatus.OK);
    }
    
    @GetMapping("/list")
    public List<reservar> consultarTodo(){
        return reservarService.findByAll();
    }
    
    @GetMapping("/list/{id}")
    public reservar consultarPorId(@PathVariable Integer id){
        return reservarService.findById(id);
    }

}  
