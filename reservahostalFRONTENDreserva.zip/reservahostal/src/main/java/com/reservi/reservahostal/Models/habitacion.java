package com.reservi.reservahostal.Models;
import java.io.Serializable;
import org.hibernate.annotations.GenericGenerator;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Entity;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

@Table
@Entity(name="habitacion")
public class habitacion implements Serializable {
   @Id
   @Column(name="numero_habi")
   private int numero_habi;
   @Column(name="tipo_habi")
   private String tipo_habi;
   @Column(name="ubicacion")
   private String ubicacion;
   @Column(name="codigo_esthab")
   private String codigo_esthab;
   @Column(name="nombre_esthab")
   private String nombre_esthab;
public habitacion(){
}
    public habitacion(int numero_habi, String tipo_habi, String ubicacion, String codigo_esthab, String nombre_esthab) {
        this.numero_habi = numero_habi;
        this.tipo_habi = tipo_habi;
        this.ubicacion = ubicacion;
        this.codigo_esthab = codigo_esthab;
        this.nombre_esthab = nombre_esthab;
    }

    public int getNumero_habi() {
        return numero_habi;
    }

    public void setNumero_habi(int numero_habi) {
        this.numero_habi = numero_habi;
    }

    public String getTipo_habi() {
        return tipo_habi;
    }

    public void setTipo_habi(String tipo_habi) {
        this.tipo_habi = tipo_habi;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public String getCodigo_esthab() {
        return codigo_esthab;
    }

    public void setCodigo_esthab(String codigo_esthab) {
        this.codigo_esthab = codigo_esthab;
    }

    public String getNombre_esthab() {
        return nombre_esthab;
    }

    public void setNombre_esthab(String nombre_esthab) {
        this.nombre_esthab = nombre_esthab;
    }
   
} 
