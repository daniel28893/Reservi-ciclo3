package com.reservi.reservahostal.DAO;
import com.reservi.reservahostal.Models.reservar;
import org.springframework.data.repository.CrudRepository;
public interface reservarDao extends CrudRepository<reservar, Integer> {
    
}
