package com.reservi.reservahostal.Service;
import com.reservi.reservahostal.Models.usuario;
import java.util.List;
public interface usuarioService {
    public usuario save(usuario usuario);
    public void delete(Integer id);
    public usuario findById(Integer id);
    public List<usuario> findByAll();
}
