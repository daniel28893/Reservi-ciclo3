package com.reservi.reservahostal.Models;
import java.io.Serializable;
import org.hibernate.annotations.GenericGenerator;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Entity;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

@Table
@Entity(name="usuario")
public class usuario implements Serializable {
   @Id
   @Column(name="id_usuario")
   private int id_usuario;
   @Column(name="nombre_usu")
   private String nombre_usu;
   @Column(name="contraseña_usu")
   private String contraseña_usu;
   @Column(name="tipo_usu")
   private String tipo_usu;

    public usuario() {
    }

    public usuario(int id_usuario, String nombre_usu, String contraseña_usu, String tipo_usu) {
        this.id_usuario = id_usuario;
        this.nombre_usu = nombre_usu;
        this.contraseña_usu = contraseña_usu;
        this.tipo_usu = tipo_usu;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public String getNombre_usu() {
        return nombre_usu;
    }

    public void setNombre_usu(String nombre_usu) {
        this.nombre_usu = nombre_usu;
    }

    public String getContraseña_usu() {
        return contraseña_usu;
    }

    public void setContraseña_usu(String contraseña_usu) {
        this.contraseña_usu = contraseña_usu;
    }

    public String getTipo_usu() {
        return tipo_usu;
    }

    public void setTipo_usu(String tipo_usu) {
        this.tipo_usu = tipo_usu;
    }
   
}
