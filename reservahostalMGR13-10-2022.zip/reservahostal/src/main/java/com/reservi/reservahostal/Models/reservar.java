package com.reservi.reservahostal.Models;
import java.io.Serializable;
import java.time.LocalDateTime;
import org.hibernate.annotations.GenericGenerator;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Entity;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Table
@Entity(name="reservar")
public class reservar {
   @Id
   @Column(name="codigo_rese")
   private int codigo_rese;
   @ManyToOne
   @JoinColumn(name="numero_habi")
   private habitacion habitacion;
   @JoinColumn(name="id_hue")
   private Huesped huesped;
   @ManyToOne
   @JoinColumn(name="id_usuario")
   private usuario usuario;
   @Column(name="fecha_reserva")
   private LocalDateTime fecha_reserva;
   @Column(name="codigo_estReser")
   private String codigo_estReser;
   @Column(name="nombre_estReser")
   private String nombre_estReser;
    public reservar() {
    }

    public reservar(int codigo_rese, habitacion habitacion, Huesped huesped, usuario usuario, LocalDateTime fecha_reserva, String codigo_estReser, String nombre_estReser) {
        this.codigo_rese = codigo_rese;
        this.habitacion = habitacion;
        this.huesped = huesped;
        this.usuario = usuario;
        this.fecha_reserva = fecha_reserva;
        this.codigo_estReser = codigo_estReser;
        this.nombre_estReser = nombre_estReser;
    }

    public int getCodigo_rese() {
        return codigo_rese;
    }

    public void setCodigo_rese(int codigo_rese) {
        this.codigo_rese = codigo_rese;
    }

    public habitacion getHabitacion() {
        return habitacion;
    }

    public void setHabitacion(habitacion habitacion) {
        this.habitacion = habitacion;
    }

    public Huesped getHuesped() {
        return huesped;
    }

    public void setHuesped(Huesped huesped) {
        this.huesped = huesped;
    }

    public usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(usuario usuario) {
        this.usuario = usuario;
    }

    public LocalDateTime getFecha_reserva() {
        return fecha_reserva;
    }

    public void setFecha_reserva(LocalDateTime fecha_reserva) {
        this.fecha_reserva = fecha_reserva;
    }

    public String getCodigo_estReser() {
        return codigo_estReser;
    }

    public void setCodigo_estReser(String codigo_estReser) {
        this.codigo_estReser = codigo_estReser;
    }

    public String getNombre_estReser() {
        return nombre_estReser;
    }

    public void setNombre_estReser(String nombre_estReser) {
        this.nombre_estReser = nombre_estReser;
    }
   
   
}
