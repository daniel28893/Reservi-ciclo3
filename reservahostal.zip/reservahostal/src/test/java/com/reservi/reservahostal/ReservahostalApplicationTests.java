package com.reservi.reservahostal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReservahostalApplicationTests {

	@Test
	void contextLoads() {
	}

}
