package com.reservi.reservahostal.Implement;
import com.reservi.reservahostal.DAO.usuarioDao;
import com.reservi.reservahostal.Models.usuario;
import com.reservi.reservahostal.Service.usuarioService;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class usuarioServiceImplement implements usuarioService {
   @Autowired
   private usuarioDao usuarioDao;
   
   @Override
   @Transactional(readOnly=false)
   public usuario save(usuario usuario){
   return usuarioDao.save(usuario);
   }
   @Override
   @Transactional(readOnly=false)
   public void  delete(Integer id){
   usuarioDao.deleteById(id);
   }
   @Override
   @Transactional(readOnly=true)
   public usuario findById(Integer id){
   return usuarioDao.findById(id).orElse(null);
   } 
   @Override
   @Transactional(readOnly=true)
   public List<usuario> findByAll(){
   return (List<usuario>)usuarioDao.findAll();
   } 
}