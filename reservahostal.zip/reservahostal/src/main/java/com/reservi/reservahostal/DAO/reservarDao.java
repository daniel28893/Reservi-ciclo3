package com.reservi.reservahostal.DAO;
import com.reservi.reservahostal.Models.reservar;
import com.reservi.reservahostal.Models.Huesped;
import com.reservi.reservahostal.Models.habitacion;
import com.reservi.reservahostal.Models.usuario;
import org.springframework.data.repository.CrudRepository;
public interface reservarDao extends CrudRepository<reservar, Integer> {
    
}
