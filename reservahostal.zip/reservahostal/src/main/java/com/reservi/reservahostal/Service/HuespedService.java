package com.reservi.reservahostal.Service;
import com.reservi.reservahostal.Models.Huesped;
import java.util.List;
public interface HuespedService {
    public Huesped save(Huesped huesped);
    public void delete(Integer id);
    public Huesped findById(Integer id);
    public List<Huesped> findByAll();
}
