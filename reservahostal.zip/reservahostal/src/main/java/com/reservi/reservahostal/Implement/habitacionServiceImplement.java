package com.reservi.reservahostal.Implement;
import com.reservi.reservahostal.DAO.habitacionDao;
import com.reservi.reservahostal.Models.habitacion;
import com.reservi.reservahostal.Service.habitacionService;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class habitacionServiceImplement implements habitacionService {
   @Autowired
   private habitacionDao habitacionDao;
   
   @Override
   @Transactional(readOnly=false)
   public habitacion save(habitacion habitacion){
   return habitacionDao.save(habitacion);
   }
   @Override
   @Transactional(readOnly=false)
   public void  delete(Integer id){
   habitacionDao.deleteById(id);
   }
   @Override
   @Transactional(readOnly=true)
   public habitacion findById(Integer id){
   return habitacionDao.findById(id).orElse(null);
   } 
   @Override
   @Transactional(readOnly=true)
   public List<habitacion> findByAll(){
   return (List<habitacion>)habitacionDao.findAll();
   } 
}