package com.reservi.reservahostal.Models;
import java.io.Serializable;
import org.hibernate.annotations.GenericGenerator;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Entity;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

@Table
@Entity(name="usuario")
public class usuario implements Serializable {
   @Id
   @Column(name="id_usuario")
   private int id_usuario;
   @Column(name="nombre_usu")
   private String nombre_usu;
   @Column(name="contraseña_usu")
   private String contraseña_usu;
   @Column(name="tipo_usu")
   private String tipo_usu;
}
