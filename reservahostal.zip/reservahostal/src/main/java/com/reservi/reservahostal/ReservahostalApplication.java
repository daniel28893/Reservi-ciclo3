package com.reservi.reservahostal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReservahostalApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReservahostalApplication.class, args);
	}

}
