package com.reservi.reservahostal.Implement;
import com.reservi.reservahostal.DAO.HuespedDao;
import com.reservi.reservahostal.Models.Huesped;
import com.reservi.reservahostal.Service.HuespedService;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class HuespedServiceImplement implements HuespedService {
   @Autowired
   private HuespedDao huespedDao;
   
   @Override
   @Transactional(readOnly=false)
   public Huesped save(Huesped huesped){
   return huespedDao.save(huesped);
   }
   @Override
   @Transactional(readOnly=false)
   public void  delete(Integer id){
   huespedDao.deleteById(id);
   }
   @Override
   @Transactional(readOnly=true)
   public Huesped findById(Integer id){
   return huespedDao.findById(id).orElse(null);
   } 
   @Override
   @Transactional(readOnly=true)
   public List<Huesped> findByAll(){
   return (List<Huesped>)huespedDao.findAll();
   } 
}
