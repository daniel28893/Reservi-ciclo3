package com.reservi.reservahostal.DAO;
import com.reservi.reservahostal.Models.habitacion;
import org.springframework.data.repository.CrudRepository;

public interface habitacionDao extends CrudRepository<habitacion,Integer>{
    
}