package com.reservi.reservahostal.Models;
import java.io.Serializable;
import org.hibernate.annotations.GenericGenerator;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Entity;
import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

@Table
@Entity(name="huesped")
public class Huesped implements Serializable {
   @Id
   @Column(name="id_hue")
   private int id_hue;
   @Column(name="nombre_hue")
   private String nombre_hue;
   @Column(name="telefono_hue")
   private String telefono_hue;
   @Column(name="email_hue")
   private String email_hue;
    public Huesped() {
    }
    public Huesped(int id_hue, String nombre_hue, String telefono_hue, String email_hue) {
        this.id_hue = id_hue;
        this.nombre_hue = nombre_hue;
        this.telefono_hue = telefono_hue;
        this.email_hue = email_hue;
    }

    public int getId_hue() {
        return id_hue;
    }

    public void setId_hue(int id_hue) {
        this.id_hue = id_hue;
    }

    public String getNombre_hue() {
        return nombre_hue;
    }

    public void setNombre_hue(String nombre_hue) {
        this.nombre_hue = nombre_hue;
    }

    public String getTelefono_hue() {
        return telefono_hue;
    }

    public void setTelefono_hue(String telefono_hue) {
        this.telefono_hue = telefono_hue;
    }

    public String getEmail_hue() {
        return email_hue;
    }

    public void setEmail_hue(String email_hue) {
        this.email_hue = email_hue;
    }
   
}
